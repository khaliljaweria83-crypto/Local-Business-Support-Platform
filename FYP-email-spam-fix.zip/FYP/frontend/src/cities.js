// Single source of truth for cities across the platform (Pakistan-wide scope).
// Used by RegisterPage/OwnerDash (when an owner picks their business's city)
// and by SearchPage/LandingPage (when a customer filters by city).
export const CITIES = [
  'Gujranwala',
  'Lahore',
  'Karachi',
  'Islamabad',
  'Rawalpindi',
  'Faisalabad',
  'Multan',
  'Peshawar',
  'Quetta',
  'Sialkot',
  'Sargodha',
  'Hyderabad',
]
