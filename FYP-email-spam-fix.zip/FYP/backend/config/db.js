const mysql = require('mysql2')
require('dotenv').config()

// Using a connection POOL instead of a single connection.
// A single connection can drop (e.g. MySQL "wait_timeout") and then every
// query after that silently fails until the server is restarted. A pool
// automatically opens/reuses/recovers connections as needed.
const db = mysql.createPool({
  host:               process.env.DB_HOST,
  user:               process.env.DB_USER,
  password:           process.env.DB_PASSWORD,
  database:           process.env.DB_NAME,
  charset:            'utf8mb4',
  waitForConnections: true,
  connectionLimit:    10,
  queueLimit:         0,
})

// Self-healing migration: creates any table that newer app code needs but
// an older imported localbiz.sql dump might not have yet (e.g. someone
// updates the code without re-importing the .sql file). Safe to run every
// startup — CREATE TABLE IF NOT EXISTS is a no-op once the table exists.
const runMigrations = () => {
  const createEmailOtps = `
    CREATE TABLE IF NOT EXISTS email_otps (
      id          INT AUTO_INCREMENT PRIMARY KEY,
      email       VARCHAR(100) NOT NULL,
      purpose     ENUM('registration', 'password_reset') NOT NULL,
      otp_hash    VARCHAR(255) NOT NULL,
      attempts    INT NOT NULL DEFAULT 0,
      verified    TINYINT(1) NOT NULL DEFAULT 0,
      expires_at  DATETIME NOT NULL,
      created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_email_purpose (email, purpose)
    )
  `
  db.query(createEmailOtps, (err) => {
    if (err) console.error('❌ Migration failed (email_otps table):', err.message)
  })
}

// Quick check on startup so we get a clear log message if MySQL/XAMPP isn't running.
db.getConnection((err, connection) => {
  if (err) {
    console.error('❌ Database connection failed:', err.message)
    return
  }
  console.log('✅ MySQL Database connected successfully!')
  connection.release()
  runMigrations()
})

module.exports = db
