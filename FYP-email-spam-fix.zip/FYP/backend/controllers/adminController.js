const db = require('../config/db')
const { sendBusinessApprovedEmail, sendBusinessRejectedEmail, sendNewReportAdminAlert } = require('../services/emailService')

// ── GET DASHBOARD STATS ──
const getDashboardStats = (req, res) => {
  const queries = {
    totalBusinesses: 'SELECT COUNT(*) AS count FROM businesses',
    totalUsers:      'SELECT COUNT(*) AS count FROM users WHERE user_type != "admin"',
    pendingApprovals:'SELECT COUNT(*) AS count FROM businesses WHERE status = "pending"',
    totalReviews:    'SELECT COUNT(*) AS count FROM reviews',
    avgRating:       'SELECT ROUND(AVG(rating), 1) AS avg FROM reviews',
    totalReports:    'SELECT COUNT(*) AS count FROM reports WHERE status = "pending"',
  }

  const stats = {}
  let completed = 0
  const total = Object.keys(queries).length

  Object.entries(queries).forEach(([key, query]) => {
    db.query(query, (err, results) => {
      if (!err) {
        stats[key] = results[0].count || results[0].avg || 0
      }
      completed++
      if (completed === total) {
        res.status(200).json(stats)
      }
    })
  })
}

// ── GET ALL PENDING BUSINESSES ──
const getPendingBusinesses = (req, res) => {
  // owner_phone is included here so the admin can actually call the owner
  // and verify the listing before approving/rejecting it — the table only
  // had owner_name/owner_email before, with no way to reach them directly.
  const query = `
    SELECT b.*, u.full_name AS owner_name, u.email AS owner_email, u.phone AS owner_phone
    FROM businesses b
    LEFT JOIN users u ON b.owner_id = u.id
    WHERE b.status = 'pending'
    ORDER BY b.created_at ASC
  `
  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    res.status(200).json(results)
  })
}

// ── APPROVE BUSINESS ──
const approveBusiness = (req, res) => {
  const { id } = req.params

  const infoQuery = `
    SELECT b.name, u.email AS owner_email
    FROM businesses b LEFT JOIN users u ON b.owner_id = u.id
    WHERE b.id = ?
  `
  db.query(infoQuery, [id], (err, info) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    if (info.length === 0) return res.status(404).json({ message: 'Business not found.' })

    const query = `
      UPDATE businesses
      SET status = 'active', is_verified = 1
      WHERE id = ?
    `
    db.query(query, [id], (err, result) => {
      if (err) return res.status(500).json({ message: 'Database error.' })
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Business not found.' })
      }

      // Log admin action
      const logQuery = `
        INSERT INTO admin_logs (admin_id, action, target_id, target_type)
        VALUES (?, 'approved_business', ?, 'business')
      `
      db.query(logQuery, [req.user.id, id], (err) => {
        if (err) console.error('Log error:', err)
      })

      sendBusinessApprovedEmail(info[0].owner_email, info[0].name)

      res.status(200).json({ message: 'Business approved successfully!' })
    })
  })
}

// ── REJECT BUSINESS ──
const rejectBusiness = (req, res) => {
  const { id } = req.params
  const { reason } = req.body

  const infoQuery = `
    SELECT b.name, u.email AS owner_email
    FROM businesses b LEFT JOIN users u ON b.owner_id = u.id
    WHERE b.id = ?
  `
  db.query(infoQuery, [id], (err, info) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    if (info.length === 0) return res.status(404).json({ message: 'Business not found.' })

    const query = `
      UPDATE businesses
      SET status = 'rejected'
      WHERE id = ?
    `
    db.query(query, [id], (err, result) => {
      if (err) return res.status(500).json({ message: 'Database error.' })
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Business not found.' })
      }

      // Log admin action
      const logQuery = `
        INSERT INTO admin_logs (admin_id, action, target_id, target_type, notes)
        VALUES (?, 'rejected_business', ?, 'business', ?)
      `
      db.query(logQuery, [req.user.id, id, reason || 'No reason provided'], (err) => {
        if (err) console.error('Log error:', err)
      })

      sendBusinessRejectedEmail(info[0].owner_email, info[0].name, reason)

      res.status(200).json({ message: 'Business rejected.' })
    })
  })
}

// ── SUSPEND BUSINESS ──
const suspendBusiness = (req, res) => {
  const { id } = req.params

  const query = `UPDATE businesses SET status = 'suspended' WHERE id = ?`
  db.query(query, [id], (err) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    res.status(200).json({ message: 'Business suspended.' })
  })
}

// ── GET ALL BUSINESSES (Admin View) ──
const getAllBusinessesAdmin = (req, res) => {
  const query = `
    SELECT b.*, u.full_name AS owner_name,
    COALESCE(AVG(r.rating), 0) AS average_rating,
    COUNT(r.id) AS review_count
    FROM businesses b
    LEFT JOIN users u ON b.owner_id = u.id
    LEFT JOIN reviews r ON b.id = r.business_id
    GROUP BY b.id
    ORDER BY b.created_at DESC
  `
  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    res.status(200).json(results)
  })
}

// ── GET ALL USERS ──
// Admin accounts are intentionally excluded here — this list is for
// moderating customers/owners, not for admins to block one another
// (or themselves).
const getAllUsers = (req, res) => {
  const query = `
    SELECT id, full_name, email, user_type, phone, status, created_at
    FROM users
    WHERE user_type != 'admin'
    ORDER BY created_at DESC
  `
  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    res.status(200).json(results)
  })
}

// ── BLOCK USER ──
const blockUser = (req, res) => {
  const { id } = req.params

  if (Number(id) === Number(req.user.id)) {
    return res.status(400).json({ message: 'You cannot block your own account.' })
  }

  const checkQuery = 'SELECT user_type FROM users WHERE id = ?'
  db.query(checkQuery, [id], (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    if (results.length === 0) return res.status(404).json({ message: 'User not found.' })
    if (results[0].user_type === 'admin') {
      return res.status(403).json({ message: 'Admin accounts cannot be blocked.' })
    }

    db.query(`UPDATE users SET status = 'blocked' WHERE id = ?`, [id], (err) => {
      if (err) return res.status(500).json({ message: 'Database error.' })

      // A blocked owner's businesses shouldn't stay live in the public
      // directory — suspend them too. (Left suspended on unblock; admin
      // reviews and reactivates each listing explicitly via All Businesses.)
      if (results[0].user_type === 'owner') {
        db.query(`UPDATE businesses SET status = 'suspended' WHERE owner_id = ? AND status = 'active'`, [id], (err) => {
          if (err) console.error('Cascade suspend error:', err)
        })
      }

      res.status(200).json({ message: 'User blocked successfully.' })
    })
  })
}

// ── UNBLOCK USER ──
const unblockUser = (req, res) => {
  const { id } = req.params

  const query = `UPDATE users SET status = 'active' WHERE id = ?`
  db.query(query, [id], (err) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    res.status(200).json({ message: 'User unblocked successfully.' })
  })
}

// ── GET ALL REPORTS ──
const getAllReports = (req, res) => {
  const query = `
    SELECT rp.*, u.full_name AS reporter_name,
    COALESCE(b.name, rb.name) AS business_name,
    rv.comment AS review_comment
    FROM reports rp
    LEFT JOIN users u ON rp.user_id = u.id
    LEFT JOIN businesses b ON rp.business_id = b.id
    LEFT JOIN reviews rv ON rp.review_id = rv.id
    LEFT JOIN businesses rb ON rv.business_id = rb.id
    ORDER BY rp.created_at DESC
  `
  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    res.status(200).json(results)
  })
}

// ── DISMISS REPORT (no action taken) ──
const dismissReport = (req, res) => {
  const { id } = req.params

  const query = `UPDATE reports SET status = 'dismissed' WHERE id = ?`
  db.query(query, [id], (err) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    res.status(200).json({ message: 'Report dismissed.' })
  })
}

// ── RESOLVE REPORT (admin took action on the reported content) ──
const resolveReport = (req, res) => {
  const { id } = req.params

  const query = `UPDATE reports SET status = 'reviewed' WHERE id = ?`
  db.query(query, [id], (err) => {
    if (err) return res.status(500).json({ message: 'Database error.' })
    res.status(200).json({ message: 'Report marked as resolved.' })
  })
}

module.exports = {
  getDashboardStats,
  getPendingBusinesses,
  approveBusiness,
  rejectBusiness,
  suspendBusiness,
  getAllBusinessesAdmin,
  getAllUsers,
  blockUser,
  unblockUser,
  getAllReports,
  dismissReport,
  resolveReport,
}
